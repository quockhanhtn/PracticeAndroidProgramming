package com.quockhanh.get_result_from_activity;

public class Const {
   public static final String KEY_FIRST_NAME = "FirstName";
   public static final String KEY_LAST_NAME = "LastName";
   public static final String KEY_GENDER = "Gender";
}
